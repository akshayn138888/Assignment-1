require 'test_helper'

class TokimonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
