class CreateTokimons < ActiveRecord::Migration
  def change
    create_table :tokimons do |t|
      t.string :name
      t.integer :weight
      t.integer :height
      t.integer :fly
      t.integer :flight
      t.integer :fire
      t.integer :water
      t.integer :electric
      t.integer :Total

      t.timestamps null: false
    end
  end
end
