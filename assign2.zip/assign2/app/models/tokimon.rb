class Tokimon < ActiveRecord::Base
  belongs_to :trainer
end
