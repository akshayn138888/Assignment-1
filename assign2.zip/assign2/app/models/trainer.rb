class Trainer < ActiveRecord::Base
  has_many :tokimons
end
